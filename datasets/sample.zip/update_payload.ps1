# Mochurin-WaSeda synthetic educational sample
# This is intentionally inert and only prints text.
Write-Output "Synthetic test file - no payload"
