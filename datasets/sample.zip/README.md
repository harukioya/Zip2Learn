# Large Pseudo ITM2 Dataset

This is a synthetic, harmless dataset for testing Mochurin-WaSeda's generic ITM2 parser.

## Purpose
The dataset intentionally mixes:
- large amounts of ordinary workstation activity
- process start events
- file creation/write events
- registry events
- multiple hosts
- educational suspicious-looking patterns such as double extensions and script execution

No executable malware, payload, exploit, or real user data is included.

## Parser compatibility
Every log is plain-text, unencrypted, and contains `type=ITM2`.
The format follows the parser contract used by `backend/parsers/itm2.py`.

## Suggested exercise
Ask learners to:
1. identify unusual process/file/registry activity,
2. distinguish normal activity from suspicious-looking activity,
3. correlate events by host and time,
4. explain why a double-extension executable or script chain deserves investigation.

The suspicious-looking events are simulated records only.

## Files intended to exercise file-risk classification

The ZIP also contains harmless synthetic files designed to exercise file-level
classification:

- `__MACOSX/._invoice.pdf` and `__MACOSX/._report.txt`: AppleDouble-style
  macOS sidecar metadata. They are not the original files.
- `unknown_file.dat`: random binary data with no known executable payload.
- `report_image.jpg`: deliberately mismatched extension/content.
- `unidentified_object`: extensionless object.
- `update_payload.ps1`: harmless script-like text.
- `unknown_program.exe`: plain text despite an executable-looking filename.

These are test artifacts only. No real malware or executable payload is included.
A classifier may therefore describe some of them as unsafe or indeterminate
because the file cannot be positively verified as safe. That is intentional.
